from experimental_landing import main

if __name__ == "__main__": main()
